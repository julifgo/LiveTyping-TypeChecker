
AUTHOR
======
[Khaled Hosny](http://www.khaledhosny.org/)

LICENSE
=======
[SIL Open Font License (OFL)](http://scripts.sil.org/OFL)

