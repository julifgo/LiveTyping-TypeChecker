# Vector Graphics in Cuis Smalltalk

[Presentation](FAST-VectorGraphicsInCuisSmalltalk.pdf) given by Juan at the [FAST talks](https://www.fast.org.ar) on January 8th, 2021.

[Video](https://www.youtube.com/watch?v=_NB2_Q4bYEk)
