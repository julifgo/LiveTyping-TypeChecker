# Live Typing

[Presentation](https://vimeo.com/593228400) given by Hernán at the [UK Smalltalk Users Group](https://www.uksmalltalk.org/) on June 30th, 2022.
