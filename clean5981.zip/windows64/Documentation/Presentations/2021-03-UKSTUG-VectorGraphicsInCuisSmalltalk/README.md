# Vector Graphics in Cuis Smalltalk

[Presentation](UKSTUG-VectorGraphicsInCuisSmalltalk.pdf) given by Juan at the [UK Smalltalk Users Group](https://www.uksmalltalk.org/) on March 31st, 2021.

[Part 1](https://vimeo.com/532636234)
[Part 2](https://vimeo.com/535191054)
[Part 3](https://vimeo.com/538096107)
