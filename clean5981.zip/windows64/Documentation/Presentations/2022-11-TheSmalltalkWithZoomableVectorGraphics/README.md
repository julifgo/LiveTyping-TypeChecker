# Cuis: The Smalltalk with a fully zoomable, vector graphics GUI

[Presentation](CuisPresentationSmalltalks2022.pdf) given by Juan at the [Smalltalks 2022](https://smalltalks2022.fast.org.ar) conference at Buenos Aires.

This is the [Video recording of the presentation](https://www.youtube.com/watch?v=7dRQ52ttZdM)
